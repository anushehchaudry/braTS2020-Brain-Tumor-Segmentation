Semantic Segmentation for Brain Tumour Segmentation (BraTS Dataset 2020)

